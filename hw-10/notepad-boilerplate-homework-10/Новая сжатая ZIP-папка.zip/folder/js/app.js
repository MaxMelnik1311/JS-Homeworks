import {PRIORITY_TYPES, ICON_TYPES, NOTE_ACTIONS} from './utils/constants';
import Notepad from './notepad-model';
import './view';
import './events';

const initialNotes = require('./notes');
const notepad = new Notepad(initialNotes);
const listRef = document.querySelector('.note-list');
renderNoteList(listRef, notepad.notes);

console.log(initialNotes);